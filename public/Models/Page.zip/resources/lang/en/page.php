<?php
	return [
		'page'=>'Page',
		'title'=>'Page Title',
		'body'=>'Page Body',
		'active'=>'Active',
		'No'=>'No',
		'Yes'=>'Yes',
		'edit'=>'edit',
		'show'=>'show',
		'delete'=>'delete',
	];
