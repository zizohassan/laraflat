<a href="{{ url('/admin/page/'.$id.'/view') }}" class="btn btn-warning btn-circle waves-effect waves-circle waves-float">
    <i class="material-icons">pageview</i>
</a>