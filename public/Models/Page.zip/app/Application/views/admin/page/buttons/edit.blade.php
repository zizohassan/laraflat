<a href="{{ url('/admin/page/item/'.$id) }}" class="btn btn-info btn-circle waves-effect waves-circle waves-float">
    <i class="material-icons">mode_edit</i>
</a>