<a href="{{ url('page/'.$id.'/view') }}" class="btn btn-warning">
    <i class="fa fa-eye"></i>
</a>