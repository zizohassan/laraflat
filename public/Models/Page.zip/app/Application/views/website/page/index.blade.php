@extends(layoutExtend('website'))

@section('title')
    {{ trans('page.page') }} {{ trans('home.control') }}
@endsection

@section('content')
    <div class="pull-{{ getDirection() }} col-lg-9">
        <div><h1>{{ trans('website.page') }}</h1></div>
        @if(auth()->check() && auth()->user()->group_id == 1)
        <div><a href="{{ url('page/item') }}" class="btn btn-default"><i
                        class="fa fa-plus"></i> {{ trans('website.page') }}</a><br></div>
        @endif
        <table class="table table-responsive table-striped table-bordered">
            <thead>
            <tr>
                <th>{{ trans("page.title") }}</th>
                @if(auth()->check() && auth()->user()->group_id == 1)
                    <th>{{ trans("page.edit") }}</th>
                    <th>{{ trans("page.show") }}</th>
                    <th>{{ trans("page.delete") }}</th>
                @endif
            </thead>
            <tbody>
            @if(count($items) > 0)
                @foreach($items as $d)
                    <tr>
                        <td>{{ str_limit(getDefaultValueKey($d->title) , 20) }}</td>
                        @if(auth()->check() && auth()->user()->group_id == 1)
                            <td>@include("website.page.buttons.edit", ["id" => $d->id ])</td>
                            <td>@include("website.page.buttons.view", ["id" => $d->id ])</td>
                            <td>@include("website.page.buttons.delete", ["id" => $d->id ])</td>
                        @endif
                    </tr>
                @endforeach
            @endif
            </tbody>
        </table>
        @include(layoutPaginate() , ["items" => $items])

    </div>
@endsection
