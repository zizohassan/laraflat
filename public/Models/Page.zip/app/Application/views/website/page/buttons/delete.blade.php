<span onclick="deleteThisItem(this)" data-link="{{ url('page/'.$id.'/delete') }}" class="btn btn-primary" >
    <i class="fa fa-trash"></i>
</span>
