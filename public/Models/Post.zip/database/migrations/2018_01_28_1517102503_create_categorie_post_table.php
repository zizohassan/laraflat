<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoriepostTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
    	Schema::table("post", function (Blueprint $table)  {
		$table->integer("categorie_id")->unsigned();
		$table->foreign("categorie_id")->references("id")->on("categorie")->onDelete("cascade");

	});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
    	Schema::disableForeignKeyConstraints();
		if (Schema::hasColumn("post", "categorie_id"))
		{
			$arrayOfKeys = $this->listTableForeignKeys("post");
			Schema::table("post", function ($table) use ($arrayOfKeys) {
			Schema::disableForeignKeyConstraints();
				if(in_array("post_categorie_id_foreign" , $arrayOfKeys)){
					$table->dropForeign("post_categorie_id_foreign");
					$table->dropColumn("categorie_id");
				}else{
					$table->dropColumn("categorie_id");
				}
			Schema::enableForeignKeyConstraints();
			});
		}
		Schema::enableForeignKeyConstraints();

    }
}
