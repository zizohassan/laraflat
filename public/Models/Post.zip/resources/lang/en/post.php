<?php
	return [
		'post'=>'Post',
		'title'=>'Post Title',
		'body'=>'Post Body',
		'active'=>'Active',
		'No'=>'No',
		'Yes'=>'Yes',
		'youtube'=>'youtube',
		'url'=>'url',
		'image'=>'image',
		'edit'=>'edit',
		'show'=>'show',
		'delete'=>'delete',
	];
