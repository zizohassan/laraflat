<?php 
                        return [
'image' => [
'height' => '300',
'width' => '300',
],
'relation' => [
'0' => [
'id' => '1',
'name' => 'categorie_post',
'options' => 'categorie,post,otm,true,title,id,id,checkbox',
'command' => 'laraflat:relation',
'p' => 'categorie',
'f' => 'post',
't' => 'otm',
'created_at' => '2018-01-28 01:21:43',
'updated_at' => '2018-01-28 01:21:43',
],
'1' => [
'id' => '2',
'name' => 'user_post',
'options' => 'user,post,otm,true,name,id,id,checkbox',
'command' => 'laraflat:relation',
'p' => 'user',
'f' => 'post',
't' => 'otm',
'created_at' => '2018-01-28 01:21:56',
'updated_at' => '2018-01-28 01:21:56',
],
],
'command' => [
'id' => '4',
'name' => 'Post',
'options' => 'title:string:min-1_max-191_required:true,body:text:min-1_required:true,active:boolean:required_integer:false,youtube:string:min-3_nullable_url:false,url:string:min-3_nullable_url:false,image:string:image-300X300_required:false',
'command' => 'laraflat:admin_model',
'created_at' => '2018-01-28 01:20:05',
'updated_at' => '2018-01-28 01:20:05',
],
];
