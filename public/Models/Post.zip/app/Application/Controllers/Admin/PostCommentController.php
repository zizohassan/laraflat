<?php

namespace App\Application\Controllers\Admin;

use \App\Application\Requests\Admin\PostComment\AddRequestPostComment;
use \App\Application\Requests\Admin\PostComment\UpdateRequestPostComment;
use App\Application\Controllers\AbstractController;
use App\Application\Model\PostComment;
use App\Application\Model\Post;
use Yajra\Datatables\Request;
use Alert;

class PostCommentController extends AbstractController
{

   public function __construct(PostComment $model , Post $parent)
    {
        parent::__construct($model);
        $this->parent = $parent;
    }

    public function addComment($id , AddRequestPostComment $request){
        $this->parent->findOrFail($id);
        $array = [
            'comment' => $request->comment,
            'user_id' => auth()->user()->id,
            'post_id' => $id
        ];
        $this->model->create($array);
        return redirect('admin/post/'.$id.'/view');
    }

    public function updateComment($id , UpdateRequestPostComment $request){
        $item =  $this->model->findOrFail($id);
        if($item->user_id != auth()->user()->id)
            return redirect('admin/post/'.$item->post_id.'/view');
        $array = [
            'comment' => $request->comment
        ];
        $item->update($array);
        return redirect('admin/post/'.$item->post_id.'/view');
    }

    public function deleteComment($id){
        $item =  $this->model->findOrFail($id);
        if($item->user_id != auth()->user()->id)
            return redirect('admin/post/'.$item->post_id.'/view');
        $item->delete();
        return redirect('admin/post/'.$item->post_id.'/view');
    }

}