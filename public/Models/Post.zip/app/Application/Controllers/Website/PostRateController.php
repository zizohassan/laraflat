<?php

namespace App\Application\Controllers\Website;

use \App\Application\Requests\Website\PostRate\AddRequestPostRate;
use \App\Application\Requests\Website\PostRate\UpdateRequestPostRate;
use App\Application\Controllers\AbstractController;
use App\Application\Model\PostRate;
use App\Application\Model\Post;
use Yajra\Datatables\Request;
use Alert;

class PostRateController extends AbstractController
{

   public function __construct(PostRate $model , Post $parent)
    {
        parent::__construct($model);
        $this->parent = $parent;
    }

    public function addRate($id , AddRequestPostRate $request){
        if($this->checkIfUserRateBefore($id)){
            alert()->error(trans('admin.You have rate this before') , trans('admin.error'));
           return redirect('admin/post/'.$id.'/view');
        }
        $array = [
            'rate' => $request->rate,
            'user_id' => auth()->user()->id,
            'post_id' => $id
        ];
        $this->model->create($array);
        return redirect('post/'.$id.'/view');
    }

    public function checkIfUserRateBefore($id){
        $item = $this->model->where('id' , $id)->where('user_id' , auth()->user()->id)->first();
        return $item ? true : false;
    }
}