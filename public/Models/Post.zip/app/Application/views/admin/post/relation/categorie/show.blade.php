		<tr>
			<th>
			{{ trans( "categorie.categorie") }}
			</th>
			<td>
				@php $categorie = App\Application\Model\Categorie::find($item->categorie_id);  @endphp
				{{ is_json($categorie->title) ? getDefaultValueKey($categorie->title) :  $categorie->title}}
			</td>
		</tr>
