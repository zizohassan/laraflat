		<div class="form-group">
			<label for="categorie">{{ trans( "categorie.categorie") }}</label>
			@php $categories = App\Application\Model\Categorie::pluck("title" ,"id")->all()  @endphp
			@php  $categorie_id = isset($item) ? $item->categorie_id : null @endphp
			<select name="categorie_id"  class="form-control" >
			@foreach( $categories as $key => $relatedItem)
			<option value="{{ $key }}"  {{ $key == $categorie_id  ? "selected" : "" }}> {{ is_json($relatedItem) ? getDefaultValueKey($relatedItem) :  $relatedItem}}</option>
			@endforeach
			</select>
		</div>
