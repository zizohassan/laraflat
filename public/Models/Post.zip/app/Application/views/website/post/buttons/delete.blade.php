<span onclick="deleteThisItem(this)" data-link="{{ url('post/'.$id.'/delete') }}" class="btn btn-primary" >
    <i class="fa fa-trash"></i>
</span>
