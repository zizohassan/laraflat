@extends(layoutExtend('website'))

@section('title')
     {{ trans('post.post') }} {{ trans('home.control') }}
@endsection

@section('content')
 <div class="pull-{{ getDirection() }} col-lg-9">
    <div><h1>{{ trans('website.post') }}</h1></div>
     <div><a href="{{ url('post/item') }}" class="btn btn-default"><i class="fa fa-plus"></i> {{ trans('website.post') }}</a><br></div>
 <table class="table table-responsive table-striped table-bordered">
		<thead>
			<tr>
				<th>{{ trans("post.title") }}</th>
				<th>{{ trans("post.body") }}</th>
				<th>{{ trans("post.active") }}</th>
				<th>{{ trans("post.youtube") }}</th>
				<th>{{ trans("post.url") }}</th>
				<th>{{ trans("post.image") }}</th>
				<th>{{ trans("post.edit") }}</th>
				<th>{{ trans("post.show") }}</th>
				<th>{{ trans("post.delete") }}</th>
				</thead>
		<tbody>
		@if(count($items) > 0)
			@foreach($items as $d)
				<tr>
					<td>{{ str_limit(getDefaultValueKey($d->title) , 20) }}</td>
				<td>{{ str_limit(getDefaultValueKey($d->body) , 20) }}</td>
									<td>
				{{ $d->active == 1 ? trans("post.Yes") : trans("post.No")  }}
					</td>
<td>{{ str_limit($d->youtube , 20) }}</td>
				<td>{{ str_limit($d->url , 20) }}</td>
									<td>
				<img src="{{ url(env("SMALL_IMAGE_PATH")."/".$d->image)}}"  width="80" />
					</td>
<td>@include("website.post.buttons.edit", ["id" => $d->id ])</td>
					<td>@include("website.post.buttons.view", ["id" => $d->id ])</td>
					<td>@include("website.post.buttons.delete", ["id" => $d->id ])</td>
					</tr>
					@endforeach
				@endif
			</tbody>
		</table>
	@include(layoutPaginate() , ["items" => $items])
		
</div>
@endsection
