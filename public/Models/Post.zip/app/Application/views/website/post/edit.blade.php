@extends(layoutExtend('website'))
 @section('title')
    {{ trans('post.post') }} {{  isset($item) ? trans('home.edit')  : trans('home.add')  }}
@endsection
 @section('content')
<div class="pull-{{ getDirection() }} col-lg-9">
         @include(layoutMessage('website'))
         <a href="{{ url('post') }}" class="btn btn-danger"><i class="fa fa-arrow-left"></i> {{ trans('website.Back') }}  </a>
        <form action="{{ concatenateLangToUrl('post/item') }}{{ isset($item) ? '/'.$item->id : '' }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            @include("website.post.relation.user.edit")
            @include("website.post.relation.categorie.edit")
               <div class="form-group">
   <label for="title">{{ trans("post.title")}}</label>
    {!! extractFiled("title" , isset($item->title) ? $item->title : old("title") , "text" , "post") !!}
   </label>
  </div>
  <div class="form-group">
   <label for="body">{{ trans("post.body")}}</label>
    {!! extractFiled("body" , isset($item->body) ? $item->body : old("body") , "textarea" , "post") !!}
   </label>
  </div>
  <div class="form-group">
   <label for="active">{{ trans("post.active")}}</label>
    <div class="form-check">
     <label class="form-check-label">
     <input class="form-check-input" name="active" {{ isset($item->active) && $item->active  == 0 ? "checked" : "" }} type="radio" value="0">
     {{ trans("post.No")}}
    </label>
    <label class="form-check-label">
    <input class="form-check-input" name="active" {{ isset($item->active) && $item->active == 1 ? "checked" : "" }} type="radio" value="1" >
         {{ trans("post.Yes")}}
    </label>
    </div>			</label>
  </div>
  <div class="form-group">
   <label for="youtube">{{ trans("post.youtube")}}</label>
    @if(isset($item) && $item->youtube != "")
    <br>
    <iframe width="420" height="315" src="https://www.youtube.com/embed/{{ isset($item->youtube) ? getYouTubeId($item->youtube) : old("youtube")  }}"></iframe>
    <br>
    @endif
    <input type="text" name="youtube" class="form-control" id="youtube" value="{{ isset($item->youtube) ? $item->youtube : old("youtube")  }}"  placeholder="{{ trans("post.youtube")}}">
   </label>
  </div>
  <div class="form-group">
   <label for="url">{{ trans("post.url")}}</label>
    <input type="text" name="url" class="form-control" id="url" value="{{ isset($item->url) ? $item->url : old("url") }}"  placeholder="{{ trans("post.url")}}">
   </label>
  </div>
  <div class="form-group">
   <label for="image">{{ trans("post.image")}}</label>
    @if(isset($item) && $item->image != "")
    <br>
    <img src="{{ url(env("SMALL_IMAGE_PATH")."/".$item->image) }}" class="thumbnail" alt="" width="200">
    <br>
    @endif
    <input type="file" name="image" >
   </label>
  </div>
             <div class="form-group">
                <button type="submit" name="submit" class="btn btn-default" >
                    <i class="fa fa-save"></i>
                    {{ trans('website.Update') }}  {{ trans('website.post') }}
                </button>
            </div>
        </form>
        @include("website.post.rate.rate")
        @include("website.post.comment.edit")
</div>
@endsection
