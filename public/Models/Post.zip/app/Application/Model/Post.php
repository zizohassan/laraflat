<?php
 namespace App\Application\Model;
 use Illuminate\Database\Eloquent\Model;
 class Post extends Model
{
   public $table = "post";
   public function user(){
		return $this->belongsTo(User::class, "user_id");
		}
   public function categorie(){
  return $this->belongsTo(Categorie::class, "categorie_id");
  }
   public function postrate(){
  return $this->hasMany(PostRate::class, "post_id");
  }
  public function postcomment(){
  return $this->hasMany(PostComment::class, "post_id");
  }
    protected $fillable = [
    'user_id',
    'categorie_id',
        'title','body','active','youtube','url','image'
   ];
 }
