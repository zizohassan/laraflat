<?php
                #### Post control
                Route::get('post', 'PostController@index');
                Route::get('post/item/{id?}', 'PostController@show');
                Route::post('post/item', 'PostController@store');
                Route::post('post/item/{id}', 'PostController@update');
                Route::get('post/{id}/delete', 'PostController@destroy');
                Route::get('post/{id}/view', 'PostController@getById');
                        Route::post('post/add/comment/{id}' , 'PostCommentController@addComment');
                        Route::post('post/update/comment/{id}' , 'PostCommentController@updateComment');
                        Route::get('post/delete/comment/{id}' , 'PostCommentController@deleteComment');
                        
                         #### post Rate
                        Route::post('post/add/rate/{id}' , 'PostRateController@addRate');
                        