<?php
 namespace App\Application\Requests\Website\Post;
 use Illuminate\Support\Facades\Route;
 class ApiUpdateRequestPost
{
    public function rules()
    {
        $id = Route::input('id');
        return [
        	"user_id" => "required|integer",
         "categorie_id" => "required|integer",
            "title.*" => "min:1|max:191|requiredbody.*",
   "image" => "image",
            ];
    }
}
