<?php
 namespace App\Application\Requests\Website\Post;
  class ApiAddRequestPost
{
    public function rules()
    {
        return [
        	"user_id" => "required|integer",
         "categorie_id" => "required|integer",
            "title.*" => "min:1|max:191|requiredbody.*",
   "image" => "image",
            ];
    }
}
